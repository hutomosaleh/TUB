#include <stdio.h>

int main()
{
	printf("Hallo\n");
	int erste_zahl = 2; // ; am Ende
	int zweite_zahl = 3;
	int dritte_zahl = 3; // int vor der Variable

	printf("Die Zahlen sind %d, %d und %d\n",
		erste_zahl, zweite_zahl, dritte_zahl);

	int vierte_zahl = 5; // kein operator als Variablename && "5" zu 5
  char zeichen = 'q'; // von Z:17 zu Z:14 verschieben
	printf("Vierte Zahl ist %d, Zeichen ist %c\n",
		vierte_zahl, zeichen); // muss zu vierte_zahl korrigiert && z in Kleinbuchstabe


	float fast_pi = 3.14; // leerzeichen mit _ ersetzen
	float besseresPi = 3.1415;
	double bestesPi = 3.141528; // double nicht mit 'a' aber mit 'o'

	printf("Alles ungefaehr pi: %f, %f, %f. A mit Umlaut %s",
		fast_pi, besseresPi, bestesPi, "Ae"); // 'fast pi' mit fast_pi ersetzen && 'Ae' mit "Ae" ersetzen
}
