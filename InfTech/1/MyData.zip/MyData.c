#include <stdio.h>

int main(){
  printf("Hutomo Rachmat Saleh | gcc (MinGW.org GCC Build-2) 9.2.0");
  return 0;
}
