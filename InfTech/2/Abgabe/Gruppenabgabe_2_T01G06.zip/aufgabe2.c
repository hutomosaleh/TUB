#include <stdio.h>

int main(void) {
    int a1, a2, a3, a4;
    int X;
    float a, b;
    float x, y;

    int loesung_1 = a1 + a2 + a3 + a4;
    int loesung_2 = 1 / X * X * X * X;
    float loesung_3 = a * b - a / b;
    x = y * 1.05; // loesung_4

    return 0;
}