#include <stdio.h>

int main(void) {
    double a, b, c, d, e;

    double loesung_1 = a / b - c / d;
    double loesung_2 = a * b / (c * d) - e;
    double loesung_3 = a + 1 / a;
    double loesung_4 = a * a + b * b + c * c;

    return 0;
}